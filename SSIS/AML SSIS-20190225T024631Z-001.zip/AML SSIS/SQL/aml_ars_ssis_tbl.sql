use hrms40
go

if exists ( select 'y' from sysobjects where name = 'aml_ars_ssis_tbl' and type = 'u')
    drop table aml_ars_ssis_tbl
go

create table aml_ars_ssis_tbl
(
employee_code		varchar(200)
,attendance_date	varchar(200)
,attendance_time	varchar(200)
,io_flag			varchar(200)
,file_name1			varchar(200)

)

go

if exists ( select 'y' from sysobjects where name = 'aml_ars_ssis_tbl' and type = 'u')
    grant all on aml_ars_ssis_tbl to public
go
